before running make sure you have oculus adb installed and added into your 
CMD environvment !

for setup help message me on discord!

- " !                       9551Dev#9551"