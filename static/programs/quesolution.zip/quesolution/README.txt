before running make sure you have side quest working and installed !
this program needs sidequest to run !

you also need developer mode enabled !

for setup help message me on discord!

- " !                       9551Dev#9551"